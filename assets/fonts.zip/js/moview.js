$(document).ready(function(){
    
    $('.slidebigbanner').slick({
        dots: true,
        infinite: true,
        speed: 500,
        fade: true,
        autoplay: true,
        autoplaySpeed: 4000,
        cssEase: 'linear',
        prevArrow: false,
        nextArrow: false
      });

});